﻿namespace Home
{
    partial class frmHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHome));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.lblUser = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.btsDashboard = new System.Windows.Forms.Button();
            this.btnDataBarang = new System.Windows.Forms.Button();
            this.btnSupplier = new System.Windows.Forms.Button();
            this.btnBrgMasuk = new System.Windows.Forms.Button();
            this.btnBrgKeluar = new System.Windows.Forms.Button();
            this.btnUpStck = new System.Windows.Forms.Button();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btnDetailBarang = new System.Windows.Forms.Button();
            this.btnSupplierD = new System.Windows.Forms.Button();
            this.btnTotalBrgMasuk = new System.Windows.Forms.Button();
            this.btnTotalTransOut = new System.Windows.Forms.Button();
            this.btnTotalTransIn = new System.Windows.Forms.Button();
            this.btnTotalBrgKeluar = new System.Windows.Forms.Button();
            this.lblJmlBrg = new System.Windows.Forms.Label();
            this.lblTTLTransOut = new System.Windows.Forms.Label();
            this.lblJmlSupp = new System.Windows.Forms.Label();
            this.lblTTLBrgOut = new System.Windows.Forms.Label();
            this.lblTTLBrgIn = new System.Windows.Forms.Label();
            this.lblTTLTransIn = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-7, -3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(279, 677);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.Location = new System.Drawing.Point(32, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(186, 35);
            this.label1.TabIndex = 1;
            this.label1.Text = "Yudha Sejahtera";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(26, 111);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(32, 36);
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new System.Drawing.Font("Poppins SemiBold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser.ForeColor = System.Drawing.Color.White;
            this.lblUser.Image = ((System.Drawing.Image)(resources.GetObject("lblUser.Image")));
            this.lblUser.Location = new System.Drawing.Point(21, 82);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(45, 26);
            this.lblUser.TabIndex = 4;
            this.lblUser.Text = "user";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Poppins SemiBold", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Image = ((System.Drawing.Image)(resources.GetObject("label2.Image")));
            this.label2.Location = new System.Drawing.Point(64, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 23);
            this.label2.TabIndex = 5;
            this.label2.Text = "Online";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.Location = new System.Drawing.Point(0, -3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(272, 73);
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(0, 137);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(272, 70);
            this.pictureBox4.TabIndex = 7;
            this.pictureBox4.TabStop = false;
            // 
            // btsDashboard
            // 
            this.btsDashboard.AutoSize = true;
            this.btsDashboard.BackColor = System.Drawing.Color.Transparent;
            this.btsDashboard.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btsDashboard.BackgroundImage")));
            this.btsDashboard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btsDashboard.FlatAppearance.BorderSize = 0;
            this.btsDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btsDashboard.Image = ((System.Drawing.Image)(resources.GetObject("btsDashboard.Image")));
            this.btsDashboard.Location = new System.Drawing.Point(12, 213);
            this.btsDashboard.Name = "btsDashboard";
            this.btsDashboard.Size = new System.Drawing.Size(192, 38);
            this.btsDashboard.TabIndex = 8;
            this.btsDashboard.UseVisualStyleBackColor = false;
            this.btsDashboard.Click += new System.EventHandler(this.btsDashboard_Click);
            // 
            // btnDataBarang
            // 
            this.btnDataBarang.AutoSize = true;
            this.btnDataBarang.BackColor = System.Drawing.Color.Transparent;
            this.btnDataBarang.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDataBarang.BackgroundImage")));
            this.btnDataBarang.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnDataBarang.FlatAppearance.BorderSize = 0;
            this.btnDataBarang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDataBarang.Image = ((System.Drawing.Image)(resources.GetObject("btnDataBarang.Image")));
            this.btnDataBarang.Location = new System.Drawing.Point(-7, 263);
            this.btnDataBarang.Margin = new System.Windows.Forms.Padding(0);
            this.btnDataBarang.Name = "btnDataBarang";
            this.btnDataBarang.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnDataBarang.Size = new System.Drawing.Size(235, 45);
            this.btnDataBarang.TabIndex = 9;
            this.btnDataBarang.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDataBarang.UseVisualStyleBackColor = false;
            this.btnDataBarang.Click += new System.EventHandler(this.btnDataBarang_Click);
            // 
            // btnSupplier
            // 
            this.btnSupplier.AutoSize = true;
            this.btnSupplier.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSupplier.BackgroundImage")));
            this.btnSupplier.FlatAppearance.BorderSize = 0;
            this.btnSupplier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSupplier.Image = ((System.Drawing.Image)(resources.GetObject("btnSupplier.Image")));
            this.btnSupplier.Location = new System.Drawing.Point(0, 322);
            this.btnSupplier.Name = "btnSupplier";
            this.btnSupplier.Size = new System.Drawing.Size(227, 49);
            this.btnSupplier.TabIndex = 10;
            this.btnSupplier.UseVisualStyleBackColor = true;
            this.btnSupplier.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnBrgMasuk
            // 
            this.btnBrgMasuk.AutoSize = true;
            this.btnBrgMasuk.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBrgMasuk.BackgroundImage")));
            this.btnBrgMasuk.FlatAppearance.BorderSize = 0;
            this.btnBrgMasuk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBrgMasuk.Image = ((System.Drawing.Image)(resources.GetObject("btnBrgMasuk.Image")));
            this.btnBrgMasuk.Location = new System.Drawing.Point(9, 377);
            this.btnBrgMasuk.Name = "btnBrgMasuk";
            this.btnBrgMasuk.Size = new System.Drawing.Size(230, 50);
            this.btnBrgMasuk.TabIndex = 11;
            this.btnBrgMasuk.UseVisualStyleBackColor = true;
            this.btnBrgMasuk.Click += new System.EventHandler(this.btnBrgMasuk_Click);
            // 
            // btnBrgKeluar
            // 
            this.btnBrgKeluar.AutoSize = true;
            this.btnBrgKeluar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBrgKeluar.BackgroundImage")));
            this.btnBrgKeluar.FlatAppearance.BorderSize = 0;
            this.btnBrgKeluar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBrgKeluar.Image = ((System.Drawing.Image)(resources.GetObject("btnBrgKeluar.Image")));
            this.btnBrgKeluar.Location = new System.Drawing.Point(-7, 433);
            this.btnBrgKeluar.Name = "btnBrgKeluar";
            this.btnBrgKeluar.Size = new System.Drawing.Size(260, 53);
            this.btnBrgKeluar.TabIndex = 12;
            this.btnBrgKeluar.UseVisualStyleBackColor = true;
            this.btnBrgKeluar.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnUpStck
            // 
            this.btnUpStck.AutoSize = true;
            this.btnUpStck.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnUpStck.BackgroundImage")));
            this.btnUpStck.FlatAppearance.BorderSize = 0;
            this.btnUpStck.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpStck.Image = ((System.Drawing.Image)(resources.GetObject("btnUpStck.Image")));
            this.btnUpStck.Location = new System.Drawing.Point(0, 492);
            this.btnUpStck.Name = "btnUpStck";
            this.btnUpStck.Size = new System.Drawing.Size(238, 47);
            this.btnUpStck.TabIndex = 13;
            this.btnUpStck.UseVisualStyleBackColor = true;
            this.btnUpStck.Click += new System.EventHandler(this.btn_Click);
            // 
            // btnLogOut
            // 
            this.btnLogOut.AutoSize = true;
            this.btnLogOut.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLogOut.BackgroundImage")));
            this.btnLogOut.FlatAppearance.BorderSize = 0;
            this.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogOut.Image = ((System.Drawing.Image)(resources.GetObject("btnLogOut.Image")));
            this.btnLogOut.Location = new System.Drawing.Point(-26, 601);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(218, 39);
            this.btnLogOut.TabIndex = 14;
            this.btnLogOut.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Poppins", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(278, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(165, 41);
            this.label3.TabIndex = 15;
            this.label3.Text = "DASHBOARD";
            // 
            // btnDetailBarang
            // 
            this.btnDetailBarang.AutoSize = true;
            this.btnDetailBarang.FlatAppearance.BorderSize = 0;
            this.btnDetailBarang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDetailBarang.Image = ((System.Drawing.Image)(resources.GetObject("btnDetailBarang.Image")));
            this.btnDetailBarang.Location = new System.Drawing.Point(285, 82);
            this.btnDetailBarang.Name = "btnDetailBarang";
            this.btnDetailBarang.Size = new System.Drawing.Size(259, 154);
            this.btnDetailBarang.TabIndex = 16;
            this.btnDetailBarang.UseVisualStyleBackColor = true;
            // 
            // btnSupplierD
            // 
            this.btnSupplierD.AutoSize = true;
            this.btnSupplierD.FlatAppearance.BorderSize = 0;
            this.btnSupplierD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSupplierD.Image = ((System.Drawing.Image)(resources.GetObject("btnSupplierD.Image")));
            this.btnSupplierD.Location = new System.Drawing.Point(285, 269);
            this.btnSupplierD.Name = "btnSupplierD";
            this.btnSupplierD.Size = new System.Drawing.Size(259, 154);
            this.btnSupplierD.TabIndex = 17;
            this.btnSupplierD.UseVisualStyleBackColor = true;
            // 
            // btnTotalBrgMasuk
            // 
            this.btnTotalBrgMasuk.AutoSize = true;
            this.btnTotalBrgMasuk.FlatAppearance.BorderSize = 0;
            this.btnTotalBrgMasuk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTotalBrgMasuk.Image = ((System.Drawing.Image)(resources.GetObject("btnTotalBrgMasuk.Image")));
            this.btnTotalBrgMasuk.Location = new System.Drawing.Point(285, 450);
            this.btnTotalBrgMasuk.Name = "btnTotalBrgMasuk";
            this.btnTotalBrgMasuk.Size = new System.Drawing.Size(259, 154);
            this.btnTotalBrgMasuk.TabIndex = 18;
            this.btnTotalBrgMasuk.UseVisualStyleBackColor = true;
            // 
            // btnTotalTransOut
            // 
            this.btnTotalTransOut.AutoSize = true;
            this.btnTotalTransOut.FlatAppearance.BorderSize = 0;
            this.btnTotalTransOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTotalTransOut.Image = ((System.Drawing.Image)(resources.GetObject("btnTotalTransOut.Image")));
            this.btnTotalTransOut.Location = new System.Drawing.Point(751, 450);
            this.btnTotalTransOut.Name = "btnTotalTransOut";
            this.btnTotalTransOut.Size = new System.Drawing.Size(259, 154);
            this.btnTotalTransOut.TabIndex = 21;
            this.btnTotalTransOut.UseVisualStyleBackColor = true;
            // 
            // btnTotalTransIn
            // 
            this.btnTotalTransIn.AutoSize = true;
            this.btnTotalTransIn.FlatAppearance.BorderSize = 0;
            this.btnTotalTransIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTotalTransIn.Image = ((System.Drawing.Image)(resources.GetObject("btnTotalTransIn.Image")));
            this.btnTotalTransIn.Location = new System.Drawing.Point(751, 263);
            this.btnTotalTransIn.Name = "btnTotalTransIn";
            this.btnTotalTransIn.Size = new System.Drawing.Size(259, 154);
            this.btnTotalTransIn.TabIndex = 20;
            this.btnTotalTransIn.UseVisualStyleBackColor = true;
            // 
            // btnTotalBrgKeluar
            // 
            this.btnTotalBrgKeluar.AutoSize = true;
            this.btnTotalBrgKeluar.FlatAppearance.BorderSize = 0;
            this.btnTotalBrgKeluar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTotalBrgKeluar.Image = ((System.Drawing.Image)(resources.GetObject("btnTotalBrgKeluar.Image")));
            this.btnTotalBrgKeluar.Location = new System.Drawing.Point(751, 82);
            this.btnTotalBrgKeluar.Name = "btnTotalBrgKeluar";
            this.btnTotalBrgKeluar.Size = new System.Drawing.Size(259, 154);
            this.btnTotalBrgKeluar.TabIndex = 19;
            this.btnTotalBrgKeluar.UseVisualStyleBackColor = true;
            // 
            // lblJmlBrg
            // 
            this.lblJmlBrg.AutoSize = true;
            this.lblJmlBrg.Font = new System.Drawing.Font("Poppins SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJmlBrg.Image = ((System.Drawing.Image)(resources.GetObject("lblJmlBrg.Image")));
            this.lblJmlBrg.Location = new System.Drawing.Point(297, 104);
            this.lblJmlBrg.Name = "lblJmlBrg";
            this.lblJmlBrg.Size = new System.Drawing.Size(129, 35);
            this.lblJmlBrg.TabIndex = 22;
            this.lblJmlBrg.Text = "JmlBarang";
            // 
            // lblTTLTransOut
            // 
            this.lblTTLTransOut.AutoSize = true;
            this.lblTTLTransOut.Font = new System.Drawing.Font("Poppins SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTTLTransOut.Image = ((System.Drawing.Image)(resources.GetObject("lblTTLTransOut.Image")));
            this.lblTTLTransOut.Location = new System.Drawing.Point(763, 469);
            this.lblTTLTransOut.Name = "lblTTLTransOut";
            this.lblTTLTransOut.Size = new System.Drawing.Size(129, 35);
            this.lblTTLTransOut.TabIndex = 23;
            this.lblTTLTransOut.Text = "JmlBarang";
            // 
            // lblJmlSupp
            // 
            this.lblJmlSupp.AutoSize = true;
            this.lblJmlSupp.Font = new System.Drawing.Font("Poppins SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJmlSupp.Image = ((System.Drawing.Image)(resources.GetObject("lblJmlSupp.Image")));
            this.lblJmlSupp.Location = new System.Drawing.Point(297, 291);
            this.lblJmlSupp.Name = "lblJmlSupp";
            this.lblJmlSupp.Size = new System.Drawing.Size(129, 35);
            this.lblJmlSupp.TabIndex = 24;
            this.lblJmlSupp.Text = "JmlBarang";
            // 
            // lblTTLBrgOut
            // 
            this.lblTTLBrgOut.AutoSize = true;
            this.lblTTLBrgOut.Font = new System.Drawing.Font("Poppins SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTTLBrgOut.Image = ((System.Drawing.Image)(resources.GetObject("lblTTLBrgOut.Image")));
            this.lblTTLBrgOut.Location = new System.Drawing.Point(763, 104);
            this.lblTTLBrgOut.Name = "lblTTLBrgOut";
            this.lblTTLBrgOut.Size = new System.Drawing.Size(129, 35);
            this.lblTTLBrgOut.TabIndex = 25;
            this.lblTTLBrgOut.Text = "JmlBarang";
            // 
            // lblTTLBrgIn
            // 
            this.lblTTLBrgIn.AutoSize = true;
            this.lblTTLBrgIn.Font = new System.Drawing.Font("Poppins SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTTLBrgIn.Image = ((System.Drawing.Image)(resources.GetObject("lblTTLBrgIn.Image")));
            this.lblTTLBrgIn.Location = new System.Drawing.Point(297, 469);
            this.lblTTLBrgIn.Name = "lblTTLBrgIn";
            this.lblTTLBrgIn.Size = new System.Drawing.Size(129, 35);
            this.lblTTLBrgIn.TabIndex = 26;
            this.lblTTLBrgIn.Text = "JmlBarang";
            // 
            // lblTTLTransIn
            // 
            this.lblTTLTransIn.AutoSize = true;
            this.lblTTLTransIn.Font = new System.Drawing.Font("Poppins SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTTLTransIn.Image = ((System.Drawing.Image)(resources.GetObject("lblTTLTransIn.Image")));
            this.lblTTLTransIn.Location = new System.Drawing.Point(763, 282);
            this.lblTTLTransIn.Name = "lblTTLTransIn";
            this.lblTTLTransIn.Size = new System.Drawing.Size(129, 35);
            this.lblTTLTransIn.TabIndex = 27;
            this.lblTTLTransIn.Text = "JmlBarang";
            // 
            // frmHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(1262, 673);
            this.Controls.Add(this.lblTTLTransIn);
            this.Controls.Add(this.lblTTLBrgIn);
            this.Controls.Add(this.lblTTLBrgOut);
            this.Controls.Add(this.lblJmlSupp);
            this.Controls.Add(this.lblTTLTransOut);
            this.Controls.Add(this.lblJmlBrg);
            this.Controls.Add(this.btnTotalTransOut);
            this.Controls.Add(this.btnTotalTransIn);
            this.Controls.Add(this.btnTotalBrgKeluar);
            this.Controls.Add(this.btnTotalBrgMasuk);
            this.Controls.Add(this.btnSupplierD);
            this.Controls.Add(this.btnDetailBarang);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.btnUpStck);
            this.Controls.Add(this.btnBrgKeluar);
            this.Controls.Add(this.btnBrgMasuk);
            this.Controls.Add(this.btnSupplier);
            this.Controls.Add(this.btnDataBarang);
            this.Controls.Add(this.btsDashboard);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "frmHome";
            this.Text = "Home";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button btsDashboard;
        private System.Windows.Forms.Button btnDataBarang;
        private System.Windows.Forms.Button btnSupplier;
        private System.Windows.Forms.Button btnBrgMasuk;
        private System.Windows.Forms.Button btnBrgKeluar;
        private System.Windows.Forms.Button btnUpStck;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnDetailBarang;
        private System.Windows.Forms.Button btnSupplierD;
        private System.Windows.Forms.Button btnTotalBrgMasuk;
        private System.Windows.Forms.Button btnTotalTransOut;
        private System.Windows.Forms.Button btnTotalTransIn;
        private System.Windows.Forms.Button btnTotalBrgKeluar;
        private System.Windows.Forms.Label lblJmlBrg;
        private System.Windows.Forms.Label lblTTLTransOut;
        private System.Windows.Forms.Label lblJmlSupp;
        private System.Windows.Forms.Label lblTTLBrgOut;
        private System.Windows.Forms.Label lblTTLBrgIn;
        private System.Windows.Forms.Label lblTTLTransIn;
    }
}

