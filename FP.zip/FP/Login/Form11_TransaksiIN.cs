﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class frmTransIN : Form
    {
        public frmTransIN()
        {
            InitializeComponent();
            InisialisasiListView();
        }

        private void InisialisasiListView()
        {
            lvwDataTransIn.View = View.Details;
            lvwDataTransIn.FullRowSelect = true;
            lvwDataTransIn.GridLines = true;

            lvwDataTransIn.Columns.Add("No.", 50, HorizontalAlignment.Center);
            lvwDataTransIn.Columns.Add("ID Trans In", 100, HorizontalAlignment.Center);
            lvwDataTransIn.Columns.Add("ID Supplier", 100, HorizontalAlignment.Center);
            lvwDataTransIn.Columns.Add("Tanggal Beli", 150, HorizontalAlignment.Center);
            lvwDataTransIn.Columns.Add("Jumlah Beli", 100, HorizontalAlignment.Center);
            lvwDataTransIn.Columns.Add("Harga Beli", 100, HorizontalAlignment.Center);
        }

        private void lvwDataDis_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            frmLogin form1 = new frmLogin();
            form1.Show();
            Visible = false;
        }

        private void btsDashboard_Click(object sender, EventArgs e)
        {
            frmHome form2 = new frmHome();
            form2.Show();
            Visible = false;
        }

        private void btnDataBarang_Click(object sender, EventArgs e)
        {
            frmDataBrg form3 = new frmDataBrg();
            form3.Show();
            Visible = false;
        }

        private void btnSupplier_Click(object sender, EventArgs e)
        {
            frmSupplier form4 = new frmSupplier();
            form4.Show();
            Visible = false;
        }

        private void btnUpStck_Click(object sender, EventArgs e)
        {
            frmUpStock form5 = new frmUpStock();
            form5.Show();
            Visible = false;
        }

        private void btnTambahTransIn_Click(object sender, EventArgs e)
        {
            frmInputTransIn form6 = new frmInputTransIn();
            form6.Show();
            Visible = false;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            frmInputTransIn form7 = new frmInputTransIn();
            form7.Show();
            Visible = false;
        }

        private void btnBrgKeluar_Click(object sender, EventArgs e)
        {
            frmTransOUT form8 = new frmTransOUT();
            form8.Show();
            Visible = false;
        }
    }
}
