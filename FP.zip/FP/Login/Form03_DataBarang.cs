﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class frmDataBrg : Form
    {
        public frmDataBrg()
        {
            InitializeComponent();
            InisialisasiListView();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {

        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            frmLogin form1 = new frmLogin();
            form1.Show();
            Visible = false;
        }

        private void lvwDataBrg_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void InisialisasiListView()
        {
           lvwDataBrg.View = View.Details;
           lvwDataBrg.FullRowSelect = true;
           lvwDataBrg.GridLines = true;

           lvwDataBrg.Columns.Add("No.", 50, HorizontalAlignment.Center);
           lvwDataBrg.Columns.Add("ID Barang", 100, HorizontalAlignment.Center);
            lvwDataBrg.Columns.Add("Nama Barang", 200, HorizontalAlignment.Center);
            lvwDataBrg.Columns.Add("Kategori", 100, HorizontalAlignment.Center);
           lvwDataBrg.Columns.Add("Stok", 70, HorizontalAlignment.Center);
           lvwDataBrg.Columns.Add("Harga Jual", 100, HorizontalAlignment.Center);
           lvwDataBrg.Columns.Add("Harga Beli", 100, HorizontalAlignment.Center);
        }

        private void btsDashboard_Click(object sender, EventArgs e)
        {
            frmHome form2 = new frmHome();
            form2.Show();
            Visible = false;
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmDataBrg_Load(object sender, EventArgs e)
        {

        }

        private void btnTambahBrg_Click(object sender, EventArgs e)
        {
            frmInputDataBrg form3 = new frmInputDataBrg();
            form3.Show();
            Visible = false;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            frmInputDataBrg form4 = new frmInputDataBrg();
            form4.Show();
            Visible = false;
        }

        private void btnDataBarang_Click(object sender, EventArgs e)
        {

        }

        private void btnLogOut_Click_1(object sender, EventArgs e)
        {
            frmLogin form1 = new frmLogin();
            form1.Show();
            Visible = false;
        }

        private void btsDashboard_Click_1(object sender, EventArgs e)
        {
            frmHome form2 = new frmHome();
            form2.Show();
            Visible = false;
        }

        private void btnUpStck_Click(object sender, EventArgs e)
        {
            frmUpStock form3 = new frmUpStock();
            form3.Show();
            Visible = false;
        }

        private void btnSupplier_Click(object sender, EventArgs e)
        {
            frmSupplier form4 = new frmSupplier();
            form4.Show();
            Visible = false;
        }

        private void btnBrgMasuk_Click(object sender, EventArgs e)
        {
            frmTransIN form5 = new frmTransIN();
            form5.Show();
            Visible = false;
        }

        private void btnBrgKeluar_Click(object sender, EventArgs e)
        {
            frmTransOUT form6 = new frmTransOUT();
            form6.Show();
            Visible = false;
        }
    }
}
