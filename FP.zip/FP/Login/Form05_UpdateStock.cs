﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class frmUpStock : Form
    {
        public frmUpStock()
        {
            InitializeComponent();
            InisialisasiListView();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btsDashboard_Click(object sender, EventArgs e)
        {
            frmHome form1 = new frmHome();
            form1.Show();
            Visible = false;
        }

        private void btnDataBarang_Click(object sender, EventArgs e)
        {
            frmDataBrg form2 = new frmDataBrg();
            form2.Show();
            Visible = false;
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            frmLogin form3 = new frmLogin();
            form3.Show();
            Visible = false;
        }

        private void lvwDataBrg_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void InisialisasiListView()
        {
            lvwDataBrg.View = View.Details;
            lvwDataBrg.FullRowSelect = true;
            lvwDataBrg.GridLines = true;

            lvwDataBrg.Columns.Add("No.", 50, HorizontalAlignment.Center);
            lvwDataBrg.Columns.Add("ID Barang", 200, HorizontalAlignment.Center);
            lvwDataBrg.Columns.Add("ID UpStock", 200, HorizontalAlignment.Center);
            lvwDataBrg.Columns.Add("Tanggal Beli", 150, HorizontalAlignment.Center);
            lvwDataBrg.Columns.Add("Jumlah Update", 100, HorizontalAlignment.Center);
        }

        private void btnTambahBrg_Click(object sender, EventArgs e)
        {
            frmInputUpStock form4 = new frmInputUpStock();
            form4.Show();
            Visible = false;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            frmInputUpStock form5 = new frmInputUpStock();
            form5.Show();
            Visible = false;
        }

        private void btnSupplier_Click(object sender, EventArgs e)
        {
            frmSupplier form6 = new frmSupplier();
            form6.Show();
            Visible = false;
        }

        private void btnBrgMasuk_Click(object sender, EventArgs e)
        {
            frmTransIN form7 = new frmTransIN();
            form7.Show();
            Visible = false;
        }

        private void btnBrgKeluar_Click(object sender, EventArgs e)
        {
            frmTransOUT form8 = new frmTransOUT();
            form8.Show();
            Visible = false;
        }
    }
}
