﻿namespace Login
{
    partial class frmInputTransIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmInputTransIn));
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.txtIdSupp = new System.Windows.Forms.TextBox();
            this.txtTglBeli = new System.Windows.Forms.TextBox();
            this.txtIdTransIn = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.btnUpStck = new System.Windows.Forms.Button();
            this.btnBrgKeluar = new System.Windows.Forms.Button();
            this.btnBrgMasuk = new System.Windows.Forms.Button();
            this.btnSupplier = new System.Windows.Forms.Button();
            this.btnDataBarang = new System.Windows.Forms.Button();
            this.btsDashboard = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtHargaBeli = new System.Windows.Forms.TextBox();
            this.txtJmlBeli = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSubmit
            // 
            this.btnSubmit.AutoSize = true;
            this.btnSubmit.BackColor = System.Drawing.Color.White;
            this.btnSubmit.FlatAppearance.BorderSize = 0;
            this.btnSubmit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSubmit.Image = ((System.Drawing.Image)(resources.GetObject("btnSubmit.Image")));
            this.btnSubmit.Location = new System.Drawing.Point(429, 553);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(107, 34);
            this.btnSubmit.TabIndex = 212;
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnBack
            // 
            this.btnBack.AutoSize = true;
            this.btnBack.BackColor = System.Drawing.Color.White;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Image = ((System.Drawing.Image)(resources.GetObject("btnBack.Image")));
            this.btnBack.Location = new System.Drawing.Point(961, 111);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(109, 35);
            this.btnBack.TabIndex = 211;
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // txtIdSupp
            // 
            this.txtIdSupp.Location = new System.Drawing.Point(431, 263);
            this.txtIdSupp.Name = "txtIdSupp";
            this.txtIdSupp.Size = new System.Drawing.Size(303, 22);
            this.txtIdSupp.TabIndex = 210;
            // 
            // txtTglBeli
            // 
            this.txtTglBeli.Location = new System.Drawing.Point(429, 336);
            this.txtTglBeli.Name = "txtTglBeli";
            this.txtTglBeli.Size = new System.Drawing.Size(303, 22);
            this.txtTglBeli.TabIndex = 209;
            // 
            // txtIdTransIn
            // 
            this.txtIdTransIn.Location = new System.Drawing.Point(431, 183);
            this.txtIdTransIn.Name = "txtIdTransIn";
            this.txtIdTransIn.Size = new System.Drawing.Size(303, 22);
            this.txtIdTransIn.TabIndex = 208;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Poppins SemiBold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(425, 307);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(126, 32);
            this.label6.TabIndex = 207;
            this.label6.Text = "Tanggal Beli";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("Poppins SemiBold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(425, 220);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 32);
            this.label5.TabIndex = 206;
            this.label5.Text = "ID Supplier";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Poppins SemiBold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(425, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(146, 32);
            this.label4.TabIndex = 205;
            this.label4.Text = "ID Transaksi In";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(350, 82);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(857, 559);
            this.pictureBox5.TabIndex = 204;
            this.pictureBox5.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Poppins", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(304, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(178, 41);
            this.label3.TabIndex = 203;
            this.label3.Text = "TRANSAKSI IN";
            // 
            // btnLogOut
            // 
            this.btnLogOut.AutoSize = true;
            this.btnLogOut.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLogOut.BackgroundImage")));
            this.btnLogOut.FlatAppearance.BorderSize = 0;
            this.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogOut.Image = ((System.Drawing.Image)(resources.GetObject("btnLogOut.Image")));
            this.btnLogOut.Location = new System.Drawing.Point(-18, 602);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(218, 39);
            this.btnLogOut.TabIndex = 202;
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // btnUpStck
            // 
            this.btnUpStck.AutoSize = true;
            this.btnUpStck.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnUpStck.BackgroundImage")));
            this.btnUpStck.FlatAppearance.BorderSize = 0;
            this.btnUpStck.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpStck.Image = ((System.Drawing.Image)(resources.GetObject("btnUpStck.Image")));
            this.btnUpStck.Location = new System.Drawing.Point(8, 493);
            this.btnUpStck.Name = "btnUpStck";
            this.btnUpStck.Size = new System.Drawing.Size(238, 47);
            this.btnUpStck.TabIndex = 201;
            this.btnUpStck.UseVisualStyleBackColor = true;
            this.btnUpStck.Click += new System.EventHandler(this.btnUpStck_Click);
            // 
            // btnBrgKeluar
            // 
            this.btnBrgKeluar.AutoSize = true;
            this.btnBrgKeluar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBrgKeluar.BackgroundImage")));
            this.btnBrgKeluar.FlatAppearance.BorderSize = 0;
            this.btnBrgKeluar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBrgKeluar.Image = ((System.Drawing.Image)(resources.GetObject("btnBrgKeluar.Image")));
            this.btnBrgKeluar.Location = new System.Drawing.Point(1, 434);
            this.btnBrgKeluar.Name = "btnBrgKeluar";
            this.btnBrgKeluar.Size = new System.Drawing.Size(260, 53);
            this.btnBrgKeluar.TabIndex = 200;
            this.btnBrgKeluar.UseVisualStyleBackColor = true;
            this.btnBrgKeluar.Click += new System.EventHandler(this.btnBrgKeluar_Click);
            // 
            // btnBrgMasuk
            // 
            this.btnBrgMasuk.AutoSize = true;
            this.btnBrgMasuk.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBrgMasuk.BackgroundImage")));
            this.btnBrgMasuk.FlatAppearance.BorderSize = 0;
            this.btnBrgMasuk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBrgMasuk.Image = ((System.Drawing.Image)(resources.GetObject("btnBrgMasuk.Image")));
            this.btnBrgMasuk.Location = new System.Drawing.Point(17, 378);
            this.btnBrgMasuk.Name = "btnBrgMasuk";
            this.btnBrgMasuk.Size = new System.Drawing.Size(230, 50);
            this.btnBrgMasuk.TabIndex = 199;
            this.btnBrgMasuk.UseVisualStyleBackColor = true;
            this.btnBrgMasuk.Click += new System.EventHandler(this.btnBrgMasuk_Click);
            // 
            // btnSupplier
            // 
            this.btnSupplier.AutoSize = true;
            this.btnSupplier.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSupplier.BackgroundImage")));
            this.btnSupplier.FlatAppearance.BorderSize = 0;
            this.btnSupplier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSupplier.Image = ((System.Drawing.Image)(resources.GetObject("btnSupplier.Image")));
            this.btnSupplier.Location = new System.Drawing.Point(8, 323);
            this.btnSupplier.Name = "btnSupplier";
            this.btnSupplier.Size = new System.Drawing.Size(227, 49);
            this.btnSupplier.TabIndex = 198;
            this.btnSupplier.UseVisualStyleBackColor = true;
            this.btnSupplier.Click += new System.EventHandler(this.btnSupplier_Click);
            // 
            // btnDataBarang
            // 
            this.btnDataBarang.AutoSize = true;
            this.btnDataBarang.BackColor = System.Drawing.Color.Transparent;
            this.btnDataBarang.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDataBarang.BackgroundImage")));
            this.btnDataBarang.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnDataBarang.FlatAppearance.BorderSize = 0;
            this.btnDataBarang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDataBarang.Image = ((System.Drawing.Image)(resources.GetObject("btnDataBarang.Image")));
            this.btnDataBarang.Location = new System.Drawing.Point(1, 264);
            this.btnDataBarang.Margin = new System.Windows.Forms.Padding(0);
            this.btnDataBarang.Name = "btnDataBarang";
            this.btnDataBarang.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnDataBarang.Size = new System.Drawing.Size(235, 45);
            this.btnDataBarang.TabIndex = 197;
            this.btnDataBarang.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDataBarang.UseVisualStyleBackColor = false;
            this.btnDataBarang.Click += new System.EventHandler(this.btnDataBarang_Click);
            // 
            // btsDashboard
            // 
            this.btsDashboard.AutoSize = true;
            this.btsDashboard.BackColor = System.Drawing.Color.Transparent;
            this.btsDashboard.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btsDashboard.BackgroundImage")));
            this.btsDashboard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btsDashboard.FlatAppearance.BorderSize = 0;
            this.btsDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btsDashboard.Image = ((System.Drawing.Image)(resources.GetObject("btsDashboard.Image")));
            this.btsDashboard.Location = new System.Drawing.Point(20, 214);
            this.btsDashboard.Name = "btsDashboard";
            this.btsDashboard.Size = new System.Drawing.Size(192, 38);
            this.btsDashboard.TabIndex = 196;
            this.btsDashboard.UseVisualStyleBackColor = false;
            this.btsDashboard.Click += new System.EventHandler(this.btsDashboard_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(8, 138);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(272, 70);
            this.pictureBox4.TabIndex = 195;
            this.pictureBox4.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Poppins SemiBold", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Image = ((System.Drawing.Image)(resources.GetObject("label2.Image")));
            this.label2.Location = new System.Drawing.Point(72, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 23);
            this.label2.TabIndex = 193;
            this.label2.Text = "Online";
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new System.Drawing.Font("Poppins SemiBold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser.ForeColor = System.Drawing.Color.White;
            this.lblUser.Image = ((System.Drawing.Image)(resources.GetObject("lblUser.Image")));
            this.lblUser.Location = new System.Drawing.Point(29, 83);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(45, 26);
            this.lblUser.TabIndex = 192;
            this.lblUser.Text = "user";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(34, 112);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(32, 36);
            this.pictureBox3.TabIndex = 191;
            this.pictureBox3.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.Location = new System.Drawing.Point(40, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(186, 35);
            this.label1.TabIndex = 190;
            this.label1.Text = "Yudha Sejahtera";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.Location = new System.Drawing.Point(1, -2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(279, 73);
            this.pictureBox2.TabIndex = 194;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(279, 677);
            this.pictureBox1.TabIndex = 189;
            this.pictureBox1.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Poppins SemiBold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(425, 378);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 32);
            this.label7.TabIndex = 214;
            this.label7.Text = "Jumlah Beli";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Font = new System.Drawing.Font("Poppins SemiBold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(425, 455);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(107, 32);
            this.label8.TabIndex = 215;
            this.label8.Text = "Harga Beli";
            // 
            // txtHargaBeli
            // 
            this.txtHargaBeli.Location = new System.Drawing.Point(429, 490);
            this.txtHargaBeli.Name = "txtHargaBeli";
            this.txtHargaBeli.Size = new System.Drawing.Size(303, 22);
            this.txtHargaBeli.TabIndex = 216;
            // 
            // txtJmlBeli
            // 
            this.txtJmlBeli.Location = new System.Drawing.Point(429, 413);
            this.txtJmlBeli.Name = "txtJmlBeli";
            this.txtJmlBeli.Size = new System.Drawing.Size(303, 22);
            this.txtJmlBeli.TabIndex = 217;
            // 
            // frmInputTransIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(1262, 673);
            this.Controls.Add(this.txtJmlBeli);
            this.Controls.Add(this.txtHargaBeli);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.txtIdSupp);
            this.Controls.Add(this.txtTglBeli);
            this.Controls.Add(this.txtIdTransIn);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.btnUpStck);
            this.Controls.Add(this.btnBrgKeluar);
            this.Controls.Add(this.btnBrgMasuk);
            this.Controls.Add(this.btnSupplier);
            this.Controls.Add(this.btnDataBarang);
            this.Controls.Add(this.btsDashboard);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmInputTransIn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Transaksi In";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.TextBox txtIdSupp;
        private System.Windows.Forms.TextBox txtTglBeli;
        private System.Windows.Forms.TextBox txtIdTransIn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Button btnUpStck;
        private System.Windows.Forms.Button btnBrgKeluar;
        private System.Windows.Forms.Button btnBrgMasuk;
        private System.Windows.Forms.Button btnSupplier;
        private System.Windows.Forms.Button btnDataBarang;
        private System.Windows.Forms.Button btsDashboard;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtHargaBeli;
        private System.Windows.Forms.TextBox txtJmlBeli;
    }
}