﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class frmInputTransOut : Form
    {
        public frmInputTransOut()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmTransOUT form1 = new frmTransOUT();
            form1.Show();
            Visible = false;
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            frmLogin form2 = new frmLogin();
            form2.Show();
            Visible = false;
        }

        private void btsDashboard_Click(object sender, EventArgs e)
        {
            frmHome form3 = new frmHome();
            form3.Show();
            Visible = false;
        }

        private void btnDataBarang_Click(object sender, EventArgs e)
        {
            frmDataBrg form4 = new frmDataBrg();
            form4.Show();
            Visible = false;
        }

        private void btnSupplier_Click(object sender, EventArgs e)
        {
            frmSupplier form5 = new frmSupplier();
            form5.Show();
            Visible = false;
        }

        private void btnBrgMasuk_Click(object sender, EventArgs e)
        {
            frmTransIN form6 = new frmTransIN();
            form6.Show();
            Visible = false;
        }

        private void btnBrgKeluar_Click(object sender, EventArgs e)
        {
            frmTransOUT form7 = new frmTransOUT();
            form7.Show();
            Visible = false;
        }

        private void btnUpStck_Click(object sender, EventArgs e)
        {
            frmUpStock form8 = new frmUpStock();
            form8.Show();
            Visible = false;
        }
    }
}
