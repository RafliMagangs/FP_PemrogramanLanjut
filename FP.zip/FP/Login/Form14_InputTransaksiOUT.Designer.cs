﻿namespace Login
{
    partial class frmInputTransOut
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmInputTransOut));
            this.txtJmlJual = new System.Windows.Forms.TextBox();
            this.txtHargaJual = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.txtIdDistri = new System.Windows.Forms.TextBox();
            this.txtTglJual = new System.Windows.Forms.TextBox();
            this.txtIdTransOut = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.btnUpStck = new System.Windows.Forms.Button();
            this.btnBrgKeluar = new System.Windows.Forms.Button();
            this.btnBrgMasuk = new System.Windows.Forms.Button();
            this.btnSupplier = new System.Windows.Forms.Button();
            this.btnDataBarang = new System.Windows.Forms.Button();
            this.btsDashboard = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtJmlJual
            // 
            this.txtJmlJual.Location = new System.Drawing.Point(428, 415);
            this.txtJmlJual.Name = "txtJmlJual";
            this.txtJmlJual.Size = new System.Drawing.Size(303, 22);
            this.txtJmlJual.TabIndex = 245;
            // 
            // txtHargaJual
            // 
            this.txtHargaJual.Location = new System.Drawing.Point(428, 492);
            this.txtHargaJual.Name = "txtHargaJual";
            this.txtHargaJual.Size = new System.Drawing.Size(303, 22);
            this.txtHargaJual.TabIndex = 244;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Font = new System.Drawing.Font("Poppins SemiBold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(424, 457);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(113, 32);
            this.label8.TabIndex = 243;
            this.label8.Text = "Harga Jual";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Poppins SemiBold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(424, 380);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(127, 32);
            this.label7.TabIndex = 242;
            this.label7.Text = "Jumlah Jual";
            // 
            // btnSubmit
            // 
            this.btnSubmit.AutoSize = true;
            this.btnSubmit.BackColor = System.Drawing.Color.White;
            this.btnSubmit.FlatAppearance.BorderSize = 0;
            this.btnSubmit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSubmit.Image = ((System.Drawing.Image)(resources.GetObject("btnSubmit.Image")));
            this.btnSubmit.Location = new System.Drawing.Point(428, 555);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(107, 34);
            this.btnSubmit.TabIndex = 241;
            this.btnSubmit.UseVisualStyleBackColor = false;
            // 
            // btnBack
            // 
            this.btnBack.AutoSize = true;
            this.btnBack.BackColor = System.Drawing.Color.White;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Image = ((System.Drawing.Image)(resources.GetObject("btnBack.Image")));
            this.btnBack.Location = new System.Drawing.Point(960, 113);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(109, 35);
            this.btnBack.TabIndex = 240;
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // txtIdDistri
            // 
            this.txtIdDistri.Location = new System.Drawing.Point(430, 265);
            this.txtIdDistri.Name = "txtIdDistri";
            this.txtIdDistri.Size = new System.Drawing.Size(303, 22);
            this.txtIdDistri.TabIndex = 239;
            // 
            // txtTglJual
            // 
            this.txtTglJual.Location = new System.Drawing.Point(428, 338);
            this.txtTglJual.Name = "txtTglJual";
            this.txtTglJual.Size = new System.Drawing.Size(303, 22);
            this.txtTglJual.TabIndex = 238;
            // 
            // txtIdTransOut
            // 
            this.txtIdTransOut.Location = new System.Drawing.Point(430, 185);
            this.txtIdTransOut.Name = "txtIdTransOut";
            this.txtIdTransOut.Size = new System.Drawing.Size(303, 22);
            this.txtIdTransOut.TabIndex = 237;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Poppins SemiBold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(424, 309);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(132, 32);
            this.label6.TabIndex = 236;
            this.label6.Text = "Tanggal Jual";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("Poppins SemiBold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(424, 222);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 32);
            this.label5.TabIndex = 235;
            this.label5.Text = "ID Distributor";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Poppins SemiBold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(424, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(162, 32);
            this.label4.TabIndex = 234;
            this.label4.Text = "ID Transaksi Out";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(349, 84);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(857, 559);
            this.pictureBox5.TabIndex = 233;
            this.pictureBox5.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Poppins", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(303, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(202, 41);
            this.label3.TabIndex = 232;
            this.label3.Text = "TRANSAKSI OUT";
            // 
            // btnLogOut
            // 
            this.btnLogOut.AutoSize = true;
            this.btnLogOut.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLogOut.BackgroundImage")));
            this.btnLogOut.FlatAppearance.BorderSize = 0;
            this.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogOut.Image = ((System.Drawing.Image)(resources.GetObject("btnLogOut.Image")));
            this.btnLogOut.Location = new System.Drawing.Point(-19, 604);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(218, 39);
            this.btnLogOut.TabIndex = 231;
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // btnUpStck
            // 
            this.btnUpStck.AutoSize = true;
            this.btnUpStck.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnUpStck.BackgroundImage")));
            this.btnUpStck.FlatAppearance.BorderSize = 0;
            this.btnUpStck.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpStck.Image = ((System.Drawing.Image)(resources.GetObject("btnUpStck.Image")));
            this.btnUpStck.Location = new System.Drawing.Point(7, 495);
            this.btnUpStck.Name = "btnUpStck";
            this.btnUpStck.Size = new System.Drawing.Size(238, 47);
            this.btnUpStck.TabIndex = 230;
            this.btnUpStck.UseVisualStyleBackColor = true;
            this.btnUpStck.Click += new System.EventHandler(this.btnUpStck_Click);
            // 
            // btnBrgKeluar
            // 
            this.btnBrgKeluar.AutoSize = true;
            this.btnBrgKeluar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBrgKeluar.BackgroundImage")));
            this.btnBrgKeluar.FlatAppearance.BorderSize = 0;
            this.btnBrgKeluar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBrgKeluar.Image = ((System.Drawing.Image)(resources.GetObject("btnBrgKeluar.Image")));
            this.btnBrgKeluar.Location = new System.Drawing.Point(0, 436);
            this.btnBrgKeluar.Name = "btnBrgKeluar";
            this.btnBrgKeluar.Size = new System.Drawing.Size(260, 53);
            this.btnBrgKeluar.TabIndex = 229;
            this.btnBrgKeluar.UseVisualStyleBackColor = true;
            this.btnBrgKeluar.Click += new System.EventHandler(this.btnBrgKeluar_Click);
            // 
            // btnBrgMasuk
            // 
            this.btnBrgMasuk.AutoSize = true;
            this.btnBrgMasuk.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBrgMasuk.BackgroundImage")));
            this.btnBrgMasuk.FlatAppearance.BorderSize = 0;
            this.btnBrgMasuk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBrgMasuk.Image = ((System.Drawing.Image)(resources.GetObject("btnBrgMasuk.Image")));
            this.btnBrgMasuk.Location = new System.Drawing.Point(16, 380);
            this.btnBrgMasuk.Name = "btnBrgMasuk";
            this.btnBrgMasuk.Size = new System.Drawing.Size(230, 50);
            this.btnBrgMasuk.TabIndex = 228;
            this.btnBrgMasuk.UseVisualStyleBackColor = true;
            this.btnBrgMasuk.Click += new System.EventHandler(this.btnBrgMasuk_Click);
            // 
            // btnSupplier
            // 
            this.btnSupplier.AutoSize = true;
            this.btnSupplier.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSupplier.BackgroundImage")));
            this.btnSupplier.FlatAppearance.BorderSize = 0;
            this.btnSupplier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSupplier.Image = ((System.Drawing.Image)(resources.GetObject("btnSupplier.Image")));
            this.btnSupplier.Location = new System.Drawing.Point(7, 325);
            this.btnSupplier.Name = "btnSupplier";
            this.btnSupplier.Size = new System.Drawing.Size(227, 49);
            this.btnSupplier.TabIndex = 227;
            this.btnSupplier.UseVisualStyleBackColor = true;
            this.btnSupplier.Click += new System.EventHandler(this.btnSupplier_Click);
            // 
            // btnDataBarang
            // 
            this.btnDataBarang.AutoSize = true;
            this.btnDataBarang.BackColor = System.Drawing.Color.Transparent;
            this.btnDataBarang.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDataBarang.BackgroundImage")));
            this.btnDataBarang.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnDataBarang.FlatAppearance.BorderSize = 0;
            this.btnDataBarang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDataBarang.Image = ((System.Drawing.Image)(resources.GetObject("btnDataBarang.Image")));
            this.btnDataBarang.Location = new System.Drawing.Point(0, 266);
            this.btnDataBarang.Margin = new System.Windows.Forms.Padding(0);
            this.btnDataBarang.Name = "btnDataBarang";
            this.btnDataBarang.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnDataBarang.Size = new System.Drawing.Size(235, 45);
            this.btnDataBarang.TabIndex = 226;
            this.btnDataBarang.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDataBarang.UseVisualStyleBackColor = false;
            this.btnDataBarang.Click += new System.EventHandler(this.btnDataBarang_Click);
            // 
            // btsDashboard
            // 
            this.btsDashboard.AutoSize = true;
            this.btsDashboard.BackColor = System.Drawing.Color.Transparent;
            this.btsDashboard.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btsDashboard.BackgroundImage")));
            this.btsDashboard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btsDashboard.FlatAppearance.BorderSize = 0;
            this.btsDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btsDashboard.Image = ((System.Drawing.Image)(resources.GetObject("btsDashboard.Image")));
            this.btsDashboard.Location = new System.Drawing.Point(19, 216);
            this.btsDashboard.Name = "btsDashboard";
            this.btsDashboard.Size = new System.Drawing.Size(192, 38);
            this.btsDashboard.TabIndex = 225;
            this.btsDashboard.UseVisualStyleBackColor = false;
            this.btsDashboard.Click += new System.EventHandler(this.btsDashboard_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(7, 140);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(272, 70);
            this.pictureBox4.TabIndex = 224;
            this.pictureBox4.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Poppins SemiBold", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Image = ((System.Drawing.Image)(resources.GetObject("label2.Image")));
            this.label2.Location = new System.Drawing.Point(71, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 23);
            this.label2.TabIndex = 222;
            this.label2.Text = "Online";
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new System.Drawing.Font("Poppins SemiBold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser.ForeColor = System.Drawing.Color.White;
            this.lblUser.Image = ((System.Drawing.Image)(resources.GetObject("lblUser.Image")));
            this.lblUser.Location = new System.Drawing.Point(28, 85);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(45, 26);
            this.lblUser.TabIndex = 221;
            this.lblUser.Text = "user";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(33, 114);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(32, 36);
            this.pictureBox3.TabIndex = 220;
            this.pictureBox3.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.Location = new System.Drawing.Point(39, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(186, 35);
            this.label1.TabIndex = 219;
            this.label1.Text = "Yudha Sejahtera";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(279, 73);
            this.pictureBox2.TabIndex = 223;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(279, 677);
            this.pictureBox1.TabIndex = 218;
            this.pictureBox1.TabStop = false;
            // 
            // frmInputTransOut
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(1262, 673);
            this.Controls.Add(this.txtJmlJual);
            this.Controls.Add(this.txtHargaJual);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.txtIdDistri);
            this.Controls.Add(this.txtTglJual);
            this.Controls.Add(this.txtIdTransOut);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.btnUpStck);
            this.Controls.Add(this.btnBrgKeluar);
            this.Controls.Add(this.btnBrgMasuk);
            this.Controls.Add(this.btnSupplier);
            this.Controls.Add(this.btnDataBarang);
            this.Controls.Add(this.btsDashboard);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmInputTransOut";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Transaksi Out";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtJmlJual;
        private System.Windows.Forms.TextBox txtHargaJual;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.TextBox txtIdDistri;
        private System.Windows.Forms.TextBox txtTglJual;
        private System.Windows.Forms.TextBox txtIdTransOut;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Button btnUpStck;
        private System.Windows.Forms.Button btnBrgKeluar;
        private System.Windows.Forms.Button btnBrgMasuk;
        private System.Windows.Forms.Button btnSupplier;
        private System.Windows.Forms.Button btnDataBarang;
        private System.Windows.Forms.Button btsDashboard;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}