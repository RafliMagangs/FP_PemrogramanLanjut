﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class frmTransOUT : Form
    {
        public frmTransOUT()
        {
            InitializeComponent();
            InisialisasiListView();
        }

        private void InisialisasiListView()
        {
            lvwDataTransOut.View = View.Details;
            lvwDataTransOut.FullRowSelect = true;
            lvwDataTransOut.GridLines = true;

            lvwDataTransOut.Columns.Add("No.", 50, HorizontalAlignment.Center);
            lvwDataTransOut.Columns.Add("ID Trans Out", 100, HorizontalAlignment.Center);
            lvwDataTransOut.Columns.Add("ID Distributor", 100, HorizontalAlignment.Center);
            lvwDataTransOut.Columns.Add("Tanggal Jual", 150, HorizontalAlignment.Center);
            lvwDataTransOut.Columns.Add("Jumlah Jual", 100, HorizontalAlignment.Center);
            lvwDataTransOut.Columns.Add("Harga Jual", 100, HorizontalAlignment.Center);
        }

        private void lvwDataTransIn_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            frmLogin form1 = new frmLogin();
            form1.Show();
            Visible = false;
        }

        private void btsDashboard_Click(object sender, EventArgs e)
        {
            frmHome form2 = new frmHome();
            form2.Show();
            Visible = false;
        }

        private void btnDataBarang_Click(object sender, EventArgs e)
        {
            frmDataBrg form3 = new frmDataBrg();
            form3.Show();
            Visible = false;
        }

        private void btnSupplier_Click(object sender, EventArgs e)
        {
            frmSupplier form4 = new frmSupplier();
            form4.Show();
            Visible = false;
        }

        private void btnBrgMasuk_Click(object sender, EventArgs e)
        {
            frmTransIN form5 = new frmTransIN();
            form5.Show();
            Visible = false;
        }

        private void btnUpStck_Click(object sender, EventArgs e)
        {
            frmUpStock form6 = new frmUpStock();
            form6.Show();
            Visible = false;
        }

        private void btnTambahTransOut_Click(object sender, EventArgs e)
        {
            frmInputTransOut form7 = new frmInputTransOut();
            form7.Show();
            Visible = false;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            frmInputTransOut form8 = new frmInputTransOut();
            form8.Show();
            Visible = false;
        }
    }
}
