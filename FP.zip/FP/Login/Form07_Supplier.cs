﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class frmSupplier : Form
    {
        public frmSupplier()
        {
            InitializeComponent();
            InisialisasiListView();
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            frmLogin form1 = new frmLogin();
            form1.Show();
            Visible = false;
        }

        private void btsDashboard_Click(object sender, EventArgs e)
        {
            frmHome form2 = new frmHome();
            form2.Show();
            Visible = false;
        }

        private void btnDataBarang_Click(object sender, EventArgs e)
        {
            frmDataBrg form3 = new frmDataBrg();
            form3.Show();
            Visible = false;
        }

        private void btnUpStck_Click(object sender, EventArgs e)
        {
            frmUpStock form4 = new frmUpStock();
            form4.Show();
            Visible = false;
        }

        private void lvwDataSup_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void InisialisasiListView()
        {
            lvwDataSup.View = View.Details;
            lvwDataSup.FullRowSelect = true;
            lvwDataSup.GridLines = true;

            lvwDataSup.Columns.Add("No.", 50, HorizontalAlignment.Center);
            lvwDataSup.Columns.Add("ID Supplier", 100, HorizontalAlignment.Center);
            lvwDataSup.Columns.Add("Nama Supplier", 200, HorizontalAlignment.Center);
            lvwDataSup.Columns.Add("Informasi Pembayaran", 300, HorizontalAlignment.Center);
        }

        private void btnTambahSup_Click(object sender, EventArgs e)
        {
            frmInputSup form5  = new frmInputSup();
            form5.Show();
            Visible = false;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {

            frmInputSup form6 = new frmInputSup();
            form6.Show();
            Visible = false;
        }

        private void btnDistri_Click(object sender, EventArgs e)
        {
            frmDataDistri form7 = new frmDataDistri();
            form7.Show();
            Visible = false;
        }

        private void btnBrgMasuk_Click(object sender, EventArgs e)
        {
            frmTransIN form7 = new frmTransIN();
            form7.Show();
            Visible = false;
        }

        private void btnBrgKeluar_Click(object sender, EventArgs e)
        {
            frmTransOUT form8 = new frmTransOUT();
            form8.Show();
            Visible = false;
        }
    }
}
