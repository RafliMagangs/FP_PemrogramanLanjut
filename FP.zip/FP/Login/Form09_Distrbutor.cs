﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class frmDataDistri : Form
    {
        public frmDataDistri()
        {
            InitializeComponent();
            InisialisasiListView();
        }

        private void InisialisasiListView()
        {
            lvwDataDis.View = View.Details;
            lvwDataDis.FullRowSelect = true;
            lvwDataDis.GridLines = true;

            lvwDataDis.Columns.Add("No.", 50, HorizontalAlignment.Center);
            lvwDataDis.Columns.Add("ID Distributor", 100, HorizontalAlignment.Center);
            lvwDataDis.Columns.Add("Nama Distributor", 200, HorizontalAlignment.Center);
            lvwDataDis.Columns.Add("Informasi Pembayaran", 300, HorizontalAlignment.Center);
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            frmLogin form1 = new frmLogin();
            form1.Show();
            Visible = false;
        }

        private void btsDashboard_Click(object sender, EventArgs e)
        {
            frmHome form2 = new frmHome();
            form2.Show();
            Visible = false;
        }

        private void btnDataBarang_Click(object sender, EventArgs e)
        {
            frmDataBrg form3 = new frmDataBrg();
            form3.Show();
            Visible = false;
        }

        private void btnSupplier_Click(object sender, EventArgs e)
        {
            frmSupplier form4 = new frmSupplier();
            form4.Show();
            Visible = false;
        }

        private void btnUpStck_Click(object sender, EventArgs e)
        {
            frmUpStock form5 = new frmUpStock();
            form5.Show();
            Visible = false;
        }

        private void btnSupp_Click(object sender, EventArgs e)
        {
            frmSupplier form6 = new frmSupplier();
            form6.Show();
            Visible = false;
        }

        private void btnTambahDis_Click(object sender, EventArgs e)
        {
            frmInputDistri form7 = new frmInputDistri();
            form7.Show();
            Visible = false;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            frmInputDistri form8 = new frmInputDistri();
            form8.Show();
            Visible = false;
        }

        private void btnBrgMasuk_Click(object sender, EventArgs e)
        {
            frmTransIN form7 = new frmTransIN();
            form7.Show();
            Visible = false;
        }

        private void btnBrgKeluar_Click(object sender, EventArgs e)
        {
            frmTransOUT form8 = new frmTransOUT();
            form8.Show();
            Visible = false;
        }
    }
}
